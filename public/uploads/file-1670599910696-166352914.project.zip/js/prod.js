const slide = document.getElementById('slide');

const changeImg = (e)=>{
    slide.src = e.src
}